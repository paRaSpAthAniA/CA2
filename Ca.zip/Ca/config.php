<?php
define('BASE_URL', '/CA2');
